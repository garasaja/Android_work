package com.mini.mvvmex01;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "Main_Activity";
    private UserRepository userRepository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AppDatabase db = Room.databaseBuilder(getApplicationContext(),
                AppDatabase.class,"db-cos")
                .fallbackToDestructiveMigration()
                .allowMainThreadQueries() //
                .build();

        userRepository = db.userRepository();

                User user = User.builder().firstName("JOOHO").lastName("CHOI").build();
                userRepository.insert(user);

                Log.d(TAG, "onCreate: 데이터가 잘 저장됨 user : " + user);




    }
}

package com.mini.mvvmex01;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface UserRepository {
    @Query("SELECT * FROM user")
    List<User> findAll();

    @Insert
    void insert(User user);
}
